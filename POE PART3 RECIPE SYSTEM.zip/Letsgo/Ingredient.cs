﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Letsgo
{
    public class Ingredient
    {
        private string name;
        private double quantity;
        private string unit;
        private string group;
        private double calory;

        public Ingredient(string name, double qty, string unit, string group, double calory)
        {
            Name = name;
            Unit = unit;
            Group = group;
            Calory = calory;
            Quantity = qty;
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Unit
        {
            get { return unit; }
            set { unit = value; }
        }

        public string Group
        {
            get { return group; }
            set { group = value; }
        }
        public double Calory
        {
            get { return calory; }
            set { calory = value; }
        }
        public double Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

       
    }
    
}
