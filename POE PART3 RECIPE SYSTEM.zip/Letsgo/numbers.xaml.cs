﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Letsgo
{
    /// <summary>
    /// Interaction logic for numbers.xaml
    /// </summary>
    public partial class numbers : Page
    {
        public numbers()
        {
            InitializeComponent();
        }

      

        private void ingredientNext_Click(object sender, RoutedEventArgs e)
        {

            uint k;
            k = Convert.ToUInt32(numTimes.Text);
            k++;
            string i = k.ToString();
            numTimes.Text = i;
            
        }
    }
}
