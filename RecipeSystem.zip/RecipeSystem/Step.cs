﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeSystem
{
    public class Step
    {
        
        public string StepDescription { get; set; }
        public Step(string step) 
        {
            StepDescription = step;
        }
    }
}
