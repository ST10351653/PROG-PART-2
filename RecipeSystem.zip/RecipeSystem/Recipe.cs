﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeSystem
{
    public delegate string caloryDelegate(double calories);
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> ingredients { get; set; }
        public List<Step> steps { get; set; }

        

        public Recipe(string name, List<Ingredient> ingredients, List<Step> steps)
        {
            Name = name;
            this.ingredients = ingredients;
            this.steps = steps;
        }

        public void Display(double factor)
        {

            caloryDelegate caloryWarning = caloryMethod;
            Console.WriteLine($"Recipe Name: {Name}");
            Console.WriteLine($"Ingredients:");
            double calories = 0;
            for (int i = 0; i < ingredients.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {ingredients[i].Quantity*factor} {ingredients[i].Name} {ingredients[i].Unit} " +
                    $"(Food Group: {ingredients[i].FoodGroup} Calories: {ingredients[i].Calory}) ");
                calories += ingredients[i].Calory;
            }
            Console.WriteLine($"Total Calories: {calories*factor}");
            Console.WriteLine(caloryWarning.Invoke(calories*factor));

            Console.WriteLine("Recipe Steps");
            for(int i = 0;i < steps.Count; i++)
            {
                Console.WriteLine($"{i+1}. {steps[i].StepDescription}");
            }
            Console.WriteLine("End of Recipe");
        }

        public string caloryMethod(double calories)
        {
            string msg = "";
            if(calories >= 300)
            {
                msg = "Calory Warning! Recipe contains more than 300 calories!";
            }
            return msg;
        }
    }
}
