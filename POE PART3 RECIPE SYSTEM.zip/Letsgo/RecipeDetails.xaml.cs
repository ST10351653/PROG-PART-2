﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Letsgo
{
    /// <summary>
    /// Interaction logic for RecipeDetails.xaml
    /// </summary>
    public partial class RecipeDetails : Page
    {
        List<Ingredient> ingredients = new List<Ingredient>();
        List<Step> steps = new List<Step>();
        List<Recipe> recipes;
        public RecipeDetails(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
        }

        private void addIngredient_Click(object sender, RoutedEventArgs e)
        {
            
            string name = ingredientName.Text;
            double quantity = double.Parse(qty.Text);
            string unitt = unit.Text;
            string group = foodGroup.Text;
            double cal = double.Parse(calories.Text);

            ingredients.Add(new Ingredient(name, quantity,unitt,group,cal));
            ingredientName.Clear();
            qty.Clear();
            unit.Clear();
            foodGroup.Clear();
            calories.Clear();
            MessageBox.Show("Ingredient Saved");
        }



        private void done_Click(object sender, RoutedEventArgs e)
        {
            string recipeNam = recipeName.Text;
            recipes.Add(new Recipe(recipeNam, ingredients, steps));
            

            ingredientName.Clear();
            qty.Clear();
            unit.Clear();
            foodGroup.Clear();
            calories.Clear();
            instruction.Clear();
            MessageBox.Show("Recipe Added");
        }

        private void addStep_Click(object sender, RoutedEventArgs e)
        {
            string instruct = instruction.Text;

            steps.Add(new Step(instruct));
            instruction.Clear();
            MessageBox.Show("Step Saved");
        }


    }
}
