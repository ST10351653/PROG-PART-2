﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Letsgo
{
    public class Recipe
    {
        private string name;
        private List<Ingredient> ingredients;
        private List<Step> steps;

        public Recipe(string name, List<Ingredient> ingredients, List<Step> steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }
        public string Name 
        { 
            get { return name; } 
            set { name = value; } 
        }

        public List<Step> Steps 
        { 
            get {  return steps; } 
            set { steps = value; } 
        }

        public List <Ingredient> Ingredients
        { 
            get { return ingredients; } 
            set { ingredients = value; }
        }

    }
}
