﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Letsgo
{
    /// <summary>
    /// Interaction logic for DisplayRecipe.xaml
    /// </summary>
    public partial class DisplayRecipe : Page
    {
        List<Recipe> recipes;
        List<Button> button = new List<Button>();
        public DisplayRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            int num = recipes.Count;

            if(num > 0 )
            {
               
                for (int i = 0; i < recipes.Count; i++)
                {
                    string output = recipes[i].Name;
                    listOutput.Items.Add(recipes[i].Name);
                    classRecipe.Items.Clear();
                }
                
            }

            else
            {
                listOutput.Items.Add("There no Recipes to display");
            }
        }

        private void view_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < recipes.Count; i++)
            {
                string output = recipes[i].Name + " \n" ;
                //listOutput.Items.Add(output);
                button.Add(new Button());
                button[i].Content = output;
                listOutput.Items.Add(button[i]);
                //view.IsEnabled = true;
            }
        }

        private void display_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetails(1);
        }

        private void SCALE1_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetails(1);
        }

        private void SCALE2_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetails(2);
        }

        private void SCALE3_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetails(3);
        }

        private void SCALE05_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipeDetails(0.5);
        }
        public void DisplayRecipeDetails(double scalingFactor)
        {
            double calCounter = 0;
            string ingredient = "";
            string name = Name;
            
            string step = "";
            foreach (var recipe in recipes)
            {
                string[] recipeIngredients = new string[recipe.Ingredients.Count];
                string[] stepRecipe = new string[recipe.Steps.Count];
                if (recipe.Name == listOutput.SelectedItem.ToString())
                {

                    foreach (var ingredients in recipe.Ingredients)
                    {
                        int i = 0;
                        ingredient = $"{i + 1}. {ingredients.Quantity*scalingFactor} {ingredients.Unit} {ingredients.Name} ({ingredients.Group} {ingredients.Calory*scalingFactor} Calories)";
                        recipeIngredients[i] = ingredient;
                        calCounter = calCounter + ingredients.Calory;
                    }
                    int j = 0;
                    foreach (var steps in recipe.Steps)
                    {
                        step = $"{j + 1}. {steps.InstructionDescription}";
                        stepRecipe[j] = step;
                    }
                }
                string ingredientOutput = String.Join('\n', recipeIngredients);
                string stepDetails = String.Join("\n", stepRecipe);

                String caloryWarning = "";
                if (calCounter*scalingFactor >= 300)
                {
                    caloryWarning = "Warning. This recipe contains More than 300 Calories!";
                }
                string recipeDetails = $"Recipe Name : {name}\n" +
                              $"Ingredients:\n {ingredientOutput}\n" +
                              $"Steps: \n {stepDetails} \n" +
                              $"Total Calories: {calCounter*scalingFactor} Calories\n" +
                              $"{caloryWarning}";
                MessageBox.Show(recipeDetails);

            }

        }

        
    }
}
