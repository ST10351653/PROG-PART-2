﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Letsgo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }


        private void home_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            workSpace.Content = new Home();

            // the frame may change but we will still do the same operations on the same data
        }
    }
}