﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Letsgo
{
    public class Step
    {
        private string instructionDescription;

        public String InstructionDescription
        {
            get { return instructionDescription; }
            set { instructionDescription = value; }
        }
        

        public Step(string instruction) 
        { 
            InstructionDescription = instruction;
        }
    }
}
