﻿using RecipeSystem;

internal class Program
{
    private static void Main(string[] args)
    {
        List<Recipe> list = new List<Recipe>(); // generic collection to store recipes
        Console.WriteLine("Welcome to Recipe system Please choose an option");
        bool isContinue = true;
        while (isContinue)
        {
            try
            {
                // menu to select a user action
                Console.WriteLine("1. Enter a new Recipe\n" + 
                                  "2. View a Recipe\n" +
                                  "3. Exit");
                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        enterDetails(list); 
                        break;
                    case 2:

                        chooseRecipe(list);
                        break;
                    case 3:
                        isContinue = false;
                        break;
                    default:
                        Console.WriteLine("Invalid entry");
                        break;
                }
            }catch(Exception ex) { Console.WriteLine(ex.ToString()); }
        }

    }
    // method to enter recipe details
    public static void enterDetails(List<Recipe> recipes)
    {
        Console.Write($"Enter recipe Name: ");
        string recipeName = Console.ReadLine();
        Console.Write("Enter number of Ingredients: ");
        int numIngredients = Convert.ToInt32(Console.ReadLine());

        List<Ingredient> ingredients = new List<Ingredient>();
        for(int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter Ingredient {i+1} name: ");
            string ingredientName = Console.ReadLine();
            Console.Write($"Enter Quantity: ");
            double quantity = Convert.ToDouble(Console.ReadLine());
            Console.Write($"Enter unit of Measure: ");
            string unit = Console.ReadLine();
            Console.Write($"Enter Food group: ");
            string foodGroup = Console.ReadLine();
            Console.Write("Enter Calories: ");
            double calories = Convert.ToDouble(Console.ReadLine());
            //  Adding ingredients details to ingredient list
            ingredients.Add(new Ingredient(ingredientName, quantity, unit, foodGroup, calories));
        }

        Console.Write($"Enter number of steps of {recipeName}: ");
        int numSteps = Convert.ToInt32(Console.ReadLine());
        List<Step> steps = new List<Step>();
        for(int i=0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i+1}: ");
            string description = Console.ReadLine() ;
            steps.Add(new Step(description));
        }
        Console.WriteLine("Recipe Added Successfully!");
        recipes.Add(new Recipe(recipeName, ingredients,steps));
    }
    // method to display recipe
    public static void chooseRecipe(List<Recipe> recipes)
    {
        if(recipes.Count == 0)
        {
            Console.WriteLine("No recipes to Display");
        }
        else
        {
            recipes.Sort((m, n) => string.Compare(m.Name, n.Name));
            Console.WriteLine($"Choose a Recipe to Display: ");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }
            int selected = Convert.ToInt32(Console.ReadLine());
            selected = selected - 1;
            recipes[selected].Display(1);
            bool viewing = true;
            while (viewing)
            {
                // displaying recipes at different scales
                Console.WriteLine("Choose Scale of Recipe :");
                Console.WriteLine($"1. Half Scale\n" +
                                  $"2. Double Scale\n" +
                                  $"3. Triple Scale\n" +
                                  $"4. Exit\n");
                double factor = Convert.ToDouble(Console.ReadLine());
                switch (factor)
                {
                    case 1:
                        recipes[selected].Display(0.5);
                        break;
                    case 2:
                        recipes[selected].Display(2);
                        break;

                    case 3:
                        recipes[selected].Display(3);
                        break;

                    case 4:
                        viewing = false;
                        break;

                    default:
                        Console.WriteLine("Invalid entry. Please try Again");
                        break;
                }
            }
        }
    }
}